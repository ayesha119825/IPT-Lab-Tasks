# Lab 5: Histogram Processing of Images


# # Lab 5: Histogram Processing of Images


# ## Step 1: Import libraries

import cv2
import numpy as np
import matplotlib.pyplot as plt
from skimage import data, exposure
print("All libraries imported successfully!")


# ## Step 2: Load and display grayscale image

img = data.coins()

print("Image Shape:", img.shape)
print("Data Type:", img.dtype)
print("Minimum Pixel Value:", img.min())
print("Maximum Pixel Value:", img.max())

plt.figure(figsize=(6,5))
plt.imshow(img, cmap='gray')
plt.title("Original Grayscale Image")
plt.show()


# ## Task 1: Calculate and display histogram

hist_cv = cv2.calcHist(
    [img], [0], None, [256], [0, 256]
)

hist_np, bins = np.histogram(
    img.ravel(), bins=256, range=(0, 256)
)

print("OpenCV Histogram Shape:", hist_cv.shape)
print("NumPy Histogram Shape:", hist_np.shape)

print("Both Histograms Equal:",
      np.array_equal(hist_cv.ravel().astype(int), hist_np))

plt.figure(figsize=(8, 4))
plt.plot(hist_np)
plt.title("Grayscale Image Histogram")
plt.xlabel("Pixel Intensity")
plt.ylabel("Frequency")
plt.show()


# ## Task 2: Brightness and contrast adjustment

bright = cv2.convertScaleAbs(
    img, alpha=1.0, beta=60
)

dark = cv2.convertScaleAbs(
    img, alpha=1.0, beta=-60
)

low_contrast = cv2.convertScaleAbs(
    img, alpha=0.4, beta=50
)

fig, ax = plt.subplots(1, 3, figsize=(12, 4))

ax[0].imshow(bright, cmap='gray', vmin=0, vmax=255)
ax[0].set_title("Bright Image")
ax[0].axis('off')

ax[1].imshow(dark, cmap='gray', vmin=0, vmax=255)
ax[1].set_title("Dark Image")
ax[1].axis('off')

ax[2].imshow(low_contrast, cmap='gray', vmin=0, vmax=255)
ax[2].set_title("Low Contrast Image")
ax[2].axis('off')
plt.tight_layout()
plt.show()


# ## Task 3: Contrast stretching

def stretch(image, low_pct, high_pct):

    low, high = np.percentile(
        image, (low_pct, high_pct)
    )

    result = np.clip(
        (image.astype(float) - low) *
        255.0 / (high - low),
        0, 255
    )

    return result.astype(np.uint8)

stretched_2_98 = stretch(low_contrast, 2, 98)

stretched_0_100 = stretch(low_contrast, 0, 100)

fig, ax = plt.subplots(1, 3, figsize=(12, 4))

ax[0].imshow(low_contrast, cmap='gray', vmin=0, vmax=255)
ax[0].set_title("Original Low Contrast")

ax[1].imshow(stretched_2_98, cmap='gray', vmin=0, vmax=255)
ax[1].set_title("Stretch 2-98")

ax[2].imshow(stretched_0_100, cmap='gray', vmin=0, vmax=255)
ax[2].set_title("Stretch 0-100")

for a in ax:
    a.axis('off')

plt.tight_layout()
plt.show()


# ## Task 4: Manual and OpenCV histogram equalization

hist, _ = np.histogram(
    low_contrast.ravel(),
    256,
    (0, 256)
)

cdf = hist.cumsum()
cdf_m = np.ma.masked_equal(cdf, 0)

cdf_m = (
    (cdf_m - cdf_m.min()) * 255 /
    (cdf_m.max() - cdf_m.min())
)

lut = np.ma.filled(
    cdf_m, 0
).astype(np.uint8)

manual_eq = lut[low_contrast]

opencv_eq = cv2.equalizeHist(low_contrast)

difference = np.max(
    np.abs(
        manual_eq.astype(int) -
        opencv_eq.astype(int)
    )
)
print("Max difference (manual vs OpenCV):", difference)

fig, ax = plt.subplots(1, 2, figsize=(10, 4))

ax[0].imshow(manual_eq, cmap='gray', vmin=0, vmax=255)
ax[0].set_title("Manual Equalization")
ax[0].axis('off')

ax[1].imshow(opencv_eq, cmap='gray', vmin=0, vmax=255)
ax[1].set_title("OpenCV Equalization")
ax[1].axis('off')

plt.tight_layout()
plt.show()


# ## Task 5: Global equalization and CLAHE

global_eq = cv2.equalizeHist(low_contrast)

plt.figure(figsize=(5, 4))
plt.imshow(global_eq, cmap='gray', vmin=0, vmax=255)
plt.title("Global Histogram Equalization")
plt.axis('off')
plt.show()

# CLAHE with different clip limits

for clip in [1, 2, 4]:

    clahe = cv2.createCLAHE(
        clipLimit=clip,
        tileGridSize=(8, 8)
    )

    result = clahe.apply(low_contrast)

    plt.figure(figsize=(5, 4))
    plt.imshow(result, cmap='gray', vmin=0, vmax=255)
    plt.title(f"CLAHE Clip Limit {clip}")
    plt.axis('off')
    plt.show()

# CLAHE with different tile sizes

for tile in [(2, 2), (4, 4), (8, 8)]:

    clahe = cv2.createCLAHE(
        clipLimit=2.0,
        tileGridSize=tile
    )

    result = clahe.apply(low_contrast)

    plt.figure(figsize=(5, 4))
    plt.imshow(result, cmap='gray', vmin=0, vmax=255)
    plt.title(f"CLAHE Tile Size {tile}")
    plt.axis('off')
    plt.show()


# ## Task 6: RGB histograms and Y-channel equalization

rgb = data.chelsea()

plt.figure(figsize=(6, 5))
plt.imshow(rgb)
plt.title("Original RGB Image")
plt.axis('off')
plt.show()

# RGB channel histograms

plt.figure(figsize=(8, 5))

for i, color in enumerate(['r', 'g', 'b']):

    hist = cv2.calcHist(
        [rgb], [i], None, [256], [0, 256]
    )

    plt.plot(hist, color=color, label=color.upper())

plt.title("RGB Channel Histograms")
plt.xlabel("Pixel Intensity")
plt.ylabel("Frequency")
plt.legend()
plt.show()

# Equalization of Y channel

ycrcb = cv2.cvtColor(
    rgb, cv2.COLOR_RGB2YCrCb
)
ycrcb[:, :, 0] = cv2.equalizeHist(
    ycrcb[:, :, 0]
)
rgb_eq = cv2.cvtColor(
    ycrcb, cv2.COLOR_YCrCb2RGB
)

fig, ax = plt.subplots(1, 2, figsize=(10, 4))

ax[0].imshow(rgb)
ax[0].set_title("Original RGB")
ax[0].axis('off')

ax[1].imshow(rgb_eq)
ax[1].set_title("Equalized Y Channel")
ax[1].axis('off')

plt.tight_layout()
plt.show()


# ## Task 7: Histogram matching

source = data.coins()

reference = data.brick()

matched = exposure.match_histograms(
    source,
    reference,
    channel_axis=None
)

matched = np.clip(
    matched, 0, 255
).astype(np.uint8)

fig, ax = plt.subplots(1, 3, figsize=(12, 4))

ax[0].imshow(source, cmap='gray', vmin=0, vmax=255)
ax[0].set_title("Source Image")
ax[0].axis('off')

ax[1].imshow(reference, cmap='gray', vmin=0, vmax=255)
ax[1].set_title("Reference Image")
ax[1].axis('off')

ax[2].imshow(matched, cmap='gray', vmin=0, vmax=255)
ax[2].set_title("Histogram Matched Image")
ax[2].axis('off')

plt.tight_layout()
plt.show()

# Compare histograms

plt.figure(figsize=(8, 4))

plt.hist(source.ravel(), bins=256,
         range=(0, 256), alpha=0.5,
         label='Source')
plt.hist(reference.ravel(), bins=256,
         range=(0, 256), alpha=0.5,
         label='Reference')
plt.hist(matched.ravel(), bins=256,
         range=(0, 256), alpha=0.5,
         label='Matched')

plt.title("Histogram Matching Comparison")
plt.xlabel("Pixel Intensity")
plt.ylabel("Frequency")
plt.legend()
plt.show()
