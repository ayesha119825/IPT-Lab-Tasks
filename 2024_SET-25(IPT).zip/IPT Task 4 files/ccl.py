import cv2
import numpy as np
import matplotlib.pyplot as plt

# Read the image in grayscale mode
gray = cv2.imread('input.jpg', cv2.IMREAD_GRAYSCALE)

# Convert to binary image
_, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)

# Connected Component Labeling with 8-connectivity
num_labels, labels, stats, centroids = cv2.connectedComponentsWithStats(
    binary, connectivity=8)

# Label 0 is the background, so subtract 1
print('Number of connected components:', num_labels - 1)

# Display the labeled image
plt.imshow(labels, cmap='nipy_spectral')
plt.title('Connected Component Labeling')
plt.axis('off')
plt.show()
