import cv2
import matplotlib.pyplot as plt

# Load the input image and convert it to grayscale
img = cv2.imread('input.jpg')
gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)

# Binary thresholding (threshold = 127)
_, binary = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)

# Show original and segmented images
plt.figure(figsize=(10, 5))
plt.subplot(1, 2, 1)
plt.imshow(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
plt.title('Original Image')
plt.axis('off')

plt.subplot(1, 2, 2)
plt.imshow(binary, cmap='gray')
plt.title('Segmented (Binary) Image')
plt.axis('off')
plt.show()
